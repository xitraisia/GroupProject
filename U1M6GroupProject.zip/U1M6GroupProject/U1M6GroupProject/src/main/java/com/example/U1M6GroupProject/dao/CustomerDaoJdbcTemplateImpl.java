package com.example.U1M6GroupProject.dao;

import org.springframework.stereotype.Repository;

@Repository
public class CustomerDaoJdbcTemplateImpl {

}
