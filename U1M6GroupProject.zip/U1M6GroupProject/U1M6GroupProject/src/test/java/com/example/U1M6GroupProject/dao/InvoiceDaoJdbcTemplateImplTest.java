package com.example.U1M6GroupProject.dao;

import static org.junit.Assert.*;

public class InvoiceDaoJdbcTemplateImplTest {

}