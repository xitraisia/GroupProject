package com.example.U1M6GroupProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class U1M6GroupProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
