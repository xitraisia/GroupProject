package com.example.U1M6GroupProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class U1M6GroupProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(U1M6GroupProjectApplication.class, args);
	}

}
