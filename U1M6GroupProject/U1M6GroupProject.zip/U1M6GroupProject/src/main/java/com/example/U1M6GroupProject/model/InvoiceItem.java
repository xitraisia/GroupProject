package com.example.U1M6GroupProject.model;

public class InvoiceItem {

}
